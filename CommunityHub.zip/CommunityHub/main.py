import functions

# Create influencers table
create_influencers_table_query = """
CREATE TABLE influencers (
    influencer_id INT PRIMARY KEY,
    first_name VARCHAR(255),
    last_name VARCHAR(255),
    dob DATE,
    gender CHAR(1) CHECK(gender IN ('M', 'F')),
    email VARCHAR(255),
    phone_number VARCHAR(15),
    date_joined DATE,
    category VARCHAR(255),
    assets DECIMAL(10, 2),
    liabilities DECIMAL(10, 2),
    bus_vent_gp DECIMAL(10, 2),
    expenses DECIMAL(10, 2)
);
"""

# Create Course table
create_course_table_query = """
CREATE TABLE Course (
    influencer_id INT,
    Course VARCHAR(255),
    College_name VARCHAR(255),
    End_date DATE,
    Enroll_date DATE,
    PRIMARY KEY (influencer_id, Course),
    FOREIGN KEY (influencer_id) REFERENCES influencers (influencer_id) ON DELETE CASCADE
);
"""

# Create Instagram table
create_instagram_table_query = """
CREATE TABLE Instagram (
    account_name VARCHAR(255) PRIMARY KEY,
    influencer_id INT,
    ad_revenue DECIMAL(10, 2),
    joining_date DATE,
    followers INT,
    engagement_rate DECIMAL(5, 2),
    audience_demographics JSON,
    FOREIGN KEY (influencer_id) REFERENCES influencers (influencer_id) ON DELETE CASCADE
);
"""

# Create posts table
create_posts_table_query = """
CREATE TABLE posts (
    post_id INT PRIMARY KEY,
    account_name VARCHAR(255),
    post_date DATE,
    likes INT,
    comments INT,
    post_type ENUM('Image', 'Video', 'Story'),
    FOREIGN KEY (account_name) REFERENCES Instagram (account_name) ON DELETE CASCADE
);
"""

# Create collaborations table
create_collaborations_table_query = """
CREATE TABLE collaborations (
    collaboration_id INT PRIMARY KEY,
    brand_name VARCHAR(255),
    influencer_id INT,
    collaboration_earnings DECIMAL(10, 2),
    collaboration_type ENUM('Product Placement', 'Sponsored Event'),
    FOREIGN KEY (influencer_id) REFERENCES influencers (influencer_id) ON DELETE CASCADE
);
"""

# Create community_engagement table
create_community_engagement_table_query = """
CREATE TABLE community_engagement (
    engagement_id INT PRIMARY KEY,
    influencer_id INT,
    event_name VARCHAR(255),
    event_date DATE,
    participants INT,
    rating DECIMAL(5, 2),
    FOREIGN KEY (influencer_id) REFERENCES influencers (influencer_id) ON DELETE CASCADE
);
"""

# Create Analytics table
create_analytics_table_query = """
CREATE TABLE Analytics (
    influencer_id INT PRIMARY KEY,
    age INT,
    studying VARCHAR(255),
    avg_net_worth DECIMAL(10, 2),
    avg_reach INT,
    FOREIGN KEY (influencer_id) REFERENCES influencers (influencer_id) ON DELETE CASCADE
);
"""
# Create Trigger to update derived columns in Analytics table
create_trigger_query = """
-- Trigger to calculate age, studying, avg_net_worth, and avg_reach before insert
CREATE TRIGGER calculate_analytics_values
BEFORE INSERT ON Analytics
FOR EACH ROW
BEGIN
    SET NEW.age = YEAR(CURDATE()) - YEAR((SELECT dob FROM influencers WHERE influencer_id = NEW.influencer_id));
    
    SET NEW.studying = (
        SELECT 
            CASE 
                WHEN CURDATE() BETWEEN Enroll_date AND End_date THEN 'Yes'
                ELSE 'No'
            END
        FROM Course 
        WHERE influencer_id = NEW.influencer_id 
        ORDER BY End_date DESC 
        LIMIT 1
    );
    
    SET NEW.avg_net_worth = (
        SELECT 
            COALESCE(SUM(assets - liabilities + bus_vent_gp + ad_revenue + collaboration_earnings - expenses), 0)
        FROM 
            influencers
        LEFT JOIN Instagram ON influencers.influencer_id = Instagram.influencer_id
        LEFT JOIN collaborations ON influencers.influencer_id = collaborations.influencer_id
        WHERE influencers.influencer_id = NEW.influencer_id
    );
    
    SET NEW.avg_reach = (
        SELECT 
            COALESCE(SUM(participants + followers + engagement_rate + likes + comments), 0)
        FROM 
            Instagram
        LEFT JOIN posts ON Instagram.account_name = posts.account_name
        LEFT JOIN community_engagement ON Instagram.influencer_id = community_engagement.influencer_id
        WHERE Instagram.influencer_id = NEW.influencer_id
    );
END;
"""
# Connecting to MySQL
connection = functions.create_connection()

# Executing queries to create tables
functions.execute_query(connection, create_influencers_table_query)
functions.execute_query(connection, create_course_table_query)
functions.execute_query(connection, create_instagram_table_query)
functions.execute_query(connection, create_posts_table_query)
functions.execute_query(connection, create_collaborations_table_query)
functions.execute_query(connection, create_community_engagement_table_query)
functions.execute_query(connection, create_analytics_table_query)
functions.execute_query(connection, create_trigger_query)

