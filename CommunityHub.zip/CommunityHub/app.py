from bottle import Bottle, run, template, request, redirect
import mysql.connector
from mysql.connector import Error

app = Bottle()

# Function to create a connection to MySQL
def create_connection():
    connection = None
    try:
        connection = mysql.connector.connect(
            host='localhost',
            database='Community_Hub',
            user='root',
            password='Sagarite@710'
        )
        if connection.is_connected():
            print("Connected to MySQL database")
            return connection
    except Error as e:
        print(f"Error: {e}")
    return connection

# Function to execute query and return cursor
def execute_query(connection, query):
    try:
        cursor = connection.cursor()
        cursor.execute(query)
        result = cursor.fetchall()  # Fetch all results to avoid "Unread result found"
        connection.commit()
        return cursor, result
    except Exception as e:
        print(f"Error executing query: {e}")
        return None, None

# Route for the root URL
@app.route('/')
def index():
    return template('index')

# Route for new influencer details
@app.route('/new_influencer')
def new_influencer():
    return template('new_influencer')

# Route to save new influencer details
@app.route('/save_new_influencer', method='POST')
def save_new_influencer():
    connection = create_connection()

    if connection:
        # Gather influencer details from the form
        influencer_id = request.forms.get('influencer_id')
        first_name = request.forms.get('first_name')
        last_name = request.forms.get('last_name')
        dob = request.forms.get('dob')
        gender = request.forms.get('gender')
        email = request.forms.get('email')
        phone_number = request.forms.get('phone_number')
        date_joined = request.forms.get('date_joined')
        category = request.forms.get('category')
        assets = request.forms.get('assets')
        liabilities = request.forms.get('liabilities')
        bus_vent_gp = request.forms.get('bus_vent_gp')
        expenses = request.forms.get('expenses')

        # Insert into the influencers table
        query = f"""
            INSERT INTO influencers
            VALUES ({influencer_id}, '{first_name}', '{last_name}', '{dob}', '{gender}', '{email}',
            '{phone_number}', '{date_joined}', '{category}', {assets}, {liabilities}, {bus_vent_gp}, {expenses});
        """
        execute_query(connection, query)

        connection.close()

        return "New influencer details saved successfully!"
    else:
        return "Failed to connect to the database."

# Route for new course details
@app.route('/new_course')
def new_course():
    return template('new_course')

# Route to save new course details
@app.route('/save_new_course', method='POST')
def save_new_course():
    connection = create_connection()

    if connection:
        # Gather course details from the form
        influencer_id = request.forms.get('influencer_id_course')
        course = request.forms.get('course')
        college_name = request.forms.get('college_name')
        end_date = request.forms.get('end_date')
        enroll_date = request.forms.get('enroll_date')

        # Insert into the Course table
        query = f"""
            INSERT INTO Course
            VALUES ({influencer_id}, '{course}', '{college_name}', '{end_date}', '{enroll_date}');
        """
        execute_query(connection, query)

        connection.close()

        return "New course details saved successfully!"
    else:
        return "Failed to connect to the database."

@app.route('/new_instagram')
def new_instagram():
    return template('new_instagram')

# Route to save new Instagram details
@app.route('/save_new_instagram', method='POST')
def save_new_instagram():
    connection = create_connection()

    if connection:
        # Gather Instagram details from the form
        account_name = request.forms.get('account_name_instagram')
        influencer_id = request.forms.get('influencer_id_instagram')
        ad_revenue = request.forms.get('ad_revenue')
        joining_date = request.forms.get('joining_date')
        followers = request.forms.get('followers')
        engagement_rate = request.forms.get('engagement_rate')
        audience_demographics = request.forms.get('audience_demographics')

        # Insert into the Instagram table
        query = f"""
            INSERT INTO Instagram
            VALUES ('{account_name}', {influencer_id}, {ad_revenue}, '{joining_date}', {followers},
            {engagement_rate}, '{audience_demographics}');
        """
        execute_query(connection, query)

        connection.close()

        return "New Instagram details saved successfully!"
    else:
        return "Failed to connect to the database."

# Route for new posts details
@app.route('/new_posts')
def new_posts():
    return template('new_posts')

# Route to save new posts details
@app.route('/save_new_posts', method='POST')
def save_new_posts():
    connection = create_connection()

    if connection:
        # Gather posts details from the form
        post_id = request.forms.get('post_id')
        account_name = request.forms.get('account_name_posts')
        post_date = request.forms.get('post_date')
        likes = request.forms.get('likes')
        comments = request.forms.get('comments')
        post_type = request.forms.get('post_type')

        # Insert into the posts table
        query = f"""
            INSERT INTO posts
            VALUES ({post_id}, '{account_name}', '{post_date}', {likes}, {comments}, '{post_type}');
        """
        execute_query(connection, query)

 
        connection.close()

        return "New posts details saved successfully!"
    else:
        return "Failed to connect to the database."

# Route for new collaborations details
@app.route('/new_collaborations')
def new_collaborations():
    return template('new_collaborations')

# Route to save new collaborations details
@app.route('/save_new_collaborations', method='POST')
def save_new_collaborations():
    connection = create_connection()

    if connection:
        # Gather collaborations details from the form
        collaboration_id = request.forms.get('collaboration_id')
        brand_name = request.forms.get('brand_name')
        influencer_id = request.forms.get('influencer_id_collaborations')
        collaboration_earnings = request.forms.get('collaboration_earnings')
        collaboration_type = request.forms.get('collaboration_type')

        # Insert into the collaborations table
        query = f"""
            INSERT INTO collaborations
            VALUES ({collaboration_id}, '{brand_name}', {influencer_id}, {collaboration_earnings}, '{collaboration_type}');
        """
        execute_query(connection, query)

        connection.close()

        return "New collaborations details saved successfully!"
    else:
        return "Failed to connect to the database."

# Route for new community_engagement details
@app.route('/new_community_engagement')
def new_community_engagement():
    return template('new_community_engagement')

# Route to save new community_engagement details
@app.route('/save_new_community_engagement', method='POST')
def save_new_community_engagement():
    connection = create_connection()

    if connection:
        # Gather community_engagement details from the form
        engagement_id = request.forms.get('engagement_id')
        influencer_id = request.forms.get('influencer_id_community_engagement')
        event_name = request.forms.get('event_name')
        event_date = request.forms.get('event_date')
        participants = request.forms.get('participants')
        rating = request.forms.get('rating')

        # Insert into the community_engagement table
        query = f"""
            INSERT INTO community_engagement
            VALUES ({engagement_id}, {influencer_id}, '{event_name}', '{event_date}', {participants}, {rating});
        """
        execute_query(connection, query)


        connection.close()

        return "New community_engagement details saved successfully!"
    else:
        return "Failed to connect to the database."

# Route to render the check and add analytics form
@app.route('/check_and_add_analytics')
def check_and_add_analytics_form():
    return template('check_and_add_analytics')

# Route to handle form submission and check/add influencer ID to analytics
@app.route('/check_and_add_analytics', method='POST')
def check_and_add_analytics():
    connection = create_connection()

    if connection:
        try:
            # Gather influencer ID from the form
            influencer_id = request.forms.get('influencer_id')

            print(f"Checking analytics for influencer ID: {influencer_id}")

            # Check if the influencer ID exists in the analytics table
            query = f"SELECT * FROM analytics WHERE influencer_id = {influencer_id}"
            cursor, result = execute_query(connection, query)

            if cursor is not None:
                if result is not None:
                    if len(result) == 0:
                        # If influencer ID doesn't exist, add it to the analytics table
                        insert_query = f"INSERT INTO analytics (influencer_id) VALUES ({influencer_id})"
                        execute_query(connection, insert_query)

                        connection.close()

                        return f"Influencer ID {influencer_id} added to analytics table!"
                    else:
                        connection.close()
                        return f"Influencer ID {influencer_id} already exists in analytics table."
                else:
                    connection.close()
                    return "Error fetching analytics query result."
            else:
                connection.close()
                return "Error executing analytics query."
        except Exception as e:
            return f"Error: {e}"
    else:
        return "Failed to connect to the database."

# Route to render template for category selection
@app.route('/analytics_by_category', method= 'GET')
def analytics_by_category_form():
    return template('analytics_by_category')

# Route to handle category selection and display analytics table
@app.route('/analytics_by_category', method='POST')
def analytics_by_category():
    connection = create_connection()

    if connection:
        try:
            # Gather category selection from the form
            category = request.forms.get('category')

            # Fetch analytics data for influencers in the selected category
            query = f"""
                SELECT *
                FROM analytics AS a
                JOIN influencers AS i ON a.influencer_id = i.influencer_id
                WHERE i.category = '{category}';
            """
            cursor, result = execute_query(connection, query)

            if cursor is not None:
                if result is not None:
                    if len(result) > 0:
                        # Do something with the analytics data, e.g., render it in a template
                        analytics_data = result
                        connection.close()

                        # Redirect to the analytics display page with the data
                        return template('analytics_display', analytics_data=analytics_data)
                    else:
                        connection.close()
                        return f"No influencers found in the category: {category}."
                else:
                    connection.close()
                    return "Error fetching analytics query result."
            else:
                connection.close()
                return "Error executing analytics query."
        except Exception as e:
            return f"Error: {e}"
    else:
        return "Failed to connect to the database."


@app.error(404)
def error404(error):
    return '404 Error: Page not found'

run(app, host='localhost', port=8000, debug=True)

